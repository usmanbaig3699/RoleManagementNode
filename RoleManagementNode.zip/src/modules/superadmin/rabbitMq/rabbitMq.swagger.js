const swagger = {
  send: {
    schema: { hide: true },
  },
};

module.exports = swagger;
