const logger = require('../../../../utils/commonUtils/logger').adminLogger;
// const caseConversion = require('../../../../utils/commonUtils/caseConversion');

const {
  apiSuccessResponse,
  apiFailResponse,
  // validationError
} = require('../../../../utils/commonUtil');

const HTTP_STATUS = require('../../../../utils/constants/httpStatus');

const Service = require('./products.service');

const moduleName = 'Products';

const List = async (req, res) => {
  logger.verbose(`Handling ${req.method} ${req.url} Route`);
  try {
    const data = await Service.list(
      moduleName,
      { ...req.query, ...req.params },
      req.session,
      logger
    );
    if (data && !data.hasError) {
      logger.verbose(
        `Handling Completed With Success On ${req.method} ${req.url} Route`
      );
      return res
        .status(HTTP_STATUS.OK)
        .send(apiSuccessResponse(data.message, data.items));
    }
    logger.verbose(
      `Handling Completed With Error On ${req.method} ${req.url} Route`
    );
    return res
      .status(HTTP_STATUS.OK)
      .send(apiFailResponse(data.message, {}, data.code));
  } catch (error) {
    logger.verbose(
      `Handling Completed With Error On ${req.method} ${req.url} Route`
    );
    logger.error(
      `Error in calling ${moduleName} list service.
      Error:: ${error}
      Trace:: ${error.stack}`
    );
    return res.status(HTTP_STATUS.OK).send(
      apiFailResponse(
        `Something went wrong, please try again later.
        Error:: ${error}`,
        {},
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

const create = async (req, res) => {
  logger.verbose(`Handling ${req.method} ${req.url} Route`);
  try {
    const data = await Service.create(
      moduleName,
      req.session,
      req.body,
      logger
    );
    if (data && !data.hasError) {
      logger.verbose(
        `Handling Completed With Success On ${req.method} ${req.url} Route`
      );
      return res
        .status(HTTP_STATUS.OK)
        .send(apiSuccessResponse(data.message, data.item));
    }
    logger.verbose(
      `Handling Completed With Error On ${req.method} ${req.url} Route`
    );
    return res
      .status(HTTP_STATUS.OK)
      .send(apiFailResponse(data.message, {}, data.code));
  } catch (error) {
    logger.verbose(
      `Handling Completed With Error On ${req.method} ${req.url} Route`
    );
    logger.error(
      `Error in calling ${moduleName} list service.
      Error:: ${error}
      Trace:: ${error.stack}`
    );
    return res.status(HTTP_STATUS.OK).send(
      apiFailResponse(
        `Something went wrong, please try again later.
        Error:: ${error}`,
        {},
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

// const update = async (req, res) => {
//   // console.log('🚀 ~ update ~ req:', req);
//   logger.verbose(`Handling ${req.method} ${req.url} Route`);
//   try {
//     // console.log("req.body",req.body)
//     const data = await Service.update(
//       moduleName,
//       req.params.projectId,
//       req.body,
//       logger
//     );
//     if (data && !data.hasError) {
//       logger.verbose(
//         `Handling Completed With Success On ${req.method} ${req.url} Route`
//       );
//       return res
//         .status(HTTP_STATUS.OK)
//         .send(apiSuccessResponse(data.message, data.item));
//     }
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     return res
//       .status(HTTP_STATUS.OK)
//       .send(apiFailResponse(data.message, {}, data.code));
//   } catch (error) {
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     logger.error(
//       `Error in calling ${moduleName} Update service.
//       Error:: ${error}
//       Trace:: ${error.stack}`
//     );
//     return res.status(HTTP_STATUS.OK).send(
//       apiFailResponse(
//         `Something went wrong, please try again later.
//         Error:: ${error}`,
//         {},
//         HTTP_STATUS.INTERNAL_SERVER_ERROR
//       )
//     );
//   }
// };

// const updateStatus = async (req, res) => {
//   // console.log('🚀 ~ update ~ req:', req);
//   logger.verbose(`Handling ${req.method} ${req.url} Route`);
//   try {
//     // console.log("req.body",req.body)
//     const data = await Service.update(
//       moduleName,
//       req.params.projectId,
//       req.body,
//       logger
//     );
//     if (data && !data.hasError) {
//       logger.verbose(
//         `Handling Completed With Success On ${req.method} ${req.url} Route`
//       );
//       return res
//         .status(HTTP_STATUS.OK)
//         .send(apiSuccessResponse(data.message, data.item));
//     }
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     return res
//       .status(HTTP_STATUS.OK)
//       .send(apiFailResponse(data.message, {}, data.code));
//   } catch (error) {
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     logger.error(
//       `Error in calling ${moduleName} Update service.
//       Error:: ${error}
//       Trace:: ${error.stack}`
//     );
//     return res.status(HTTP_STATUS.OK).send(
//       apiFailResponse(
//         `Something went wrong, please try again later.
//         Error:: ${error}`,
//         {},
//         HTTP_STATUS.INTERNAL_SERVER_ERROR
//       )
//     );
//   }
// };

// const deleteStatus = async (req, res) => {
//   // console.log('🚀 ~ update ~ req:', req);
//   logger.verbose(`Handling ${req.method} ${req.url} Route`);
//   try {
//     // console.log("req.body",req.body)
//     const data = await Service.update(
//       moduleName,
//       req.params.projectId,
//       req.body,
//       logger
//     );
//     if (data && !data.hasError) {
//       logger.verbose(
//         `Handling Completed With Success On ${req.method} ${req.url} Route`
//       );
//       return res
//         .status(HTTP_STATUS.OK)
//         .send(apiSuccessResponse(data.message, data.item));
//     }
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     return res
//       .status(HTTP_STATUS.OK)
//       .send(apiFailResponse(data.message, {}, data.code));
//   } catch (error) {
//     logger.verbose(
//       `Handling Completed With Error On ${req.method} ${req.url} Route`
//     );
//     logger.error(
//       `Error in calling ${moduleName} Update service.
//       Error:: ${error}
//       Trace:: ${error.stack}`
//     );
//     return res.status(HTTP_STATUS.OK).send(
//       apiFailResponse(
//         `Something went wrong, please try again later.
//         Error:: ${error}`,
//         {},
//         HTTP_STATUS.INTERNAL_SERVER_ERROR
//       )
//     );
//   }
// };

module.exports = {
  List,
  create,
  // update,
  // updateStatus,
  // deleteStatus
};
