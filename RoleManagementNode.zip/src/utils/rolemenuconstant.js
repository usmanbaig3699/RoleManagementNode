const roleMenu = [
  { perm: 'addUser', url: '/user/newUser' },
  { perm: 'viewUser', url: '/user/getUserById' },
];
module.exports = { roleMenu };
