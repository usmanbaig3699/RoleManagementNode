function prettyPrintJSON(data) {
  return JSON.stringify(data, null, 2);
}
module.exports = { prettyPrintJSON };
