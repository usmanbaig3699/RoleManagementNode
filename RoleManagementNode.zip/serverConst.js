const globalVars = { rootPath: __dirname };

module.exports = { globalVars };
